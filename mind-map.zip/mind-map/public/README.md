MindMap.

To run locally, make sure you have MongoDB installed.
Before running the app, you need to start mongod with the specified --dbpath

to intall dependencies:
 npm install
 
to run app:
 node app.js